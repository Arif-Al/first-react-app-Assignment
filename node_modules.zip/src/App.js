import './App.css';
import Footer from './Components/footer/footer';
import Header from './Components/Header and hero/Index';
import Third from './Components/third-seacrion/third';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";

 

function App() {
  return (
    <div className="App">
      <Header /> 
      <Third />
      <Footer />
     
    </div>
  );
}

export default App;
